let currentSlide = 0;
const slides = document.querySelectorAll('.banner-slide');
const totalSlides = slides.length;

function showSlide(index) {
    const slideWidth = slides[0].clientWidth;
    const bannerSlides = document.querySelector('.banner-slides');
    
    bannerSlides.style.transform = `translateX(${-index * slideWidth}px)`;
}

// Función para ir al siguiente slide
function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    showSlide(currentSlide);
}

// Función para ir al slide anterior
function prevSlide() {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides; // Asegurarse de que no sea negativo
    showSlide(currentSlide);
}

// Asignar eventos a los botones
document.getElementById('nextBtn').onclick = nextSlide;
document.getElementById('prevBtn').onclick = prevSlide;

// Inicializar el primer slide
showSlide(currentSlide);

// Cambiar automáticamente de slide cada cierto tiempo
setInterval(nextSlide, 5000);