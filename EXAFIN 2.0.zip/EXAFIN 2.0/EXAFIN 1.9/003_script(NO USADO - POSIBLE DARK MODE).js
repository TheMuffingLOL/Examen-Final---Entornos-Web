const optionsModal = document.getElementById("optionsModal");
const openOptionsModalButton = document.getElementById("openOptionsModal");
const closeOptionsModalButton = document.getElementById("closeOptionsModal");
const darkModeToggle = document.getElementById("darkModeToggle");

// Función para abrir el modal de opciones
openOptionsModalButton.onclick = function() {
    optionsModal.style.display = "block";
}

// Función para cerrar el modal de opciones
closeOptionsModalButton.onclick = function() {
    optionsModal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == optionsModal) {
        optionsModal.style.display = "none";
    }
}

darkModeToggle.onchange = function() {
    if (darkModeToggle.checked) {
        document.body.classList.add("dark-mode");
    } else {
        document.body.classList.remove("dark-mode");
    }
}