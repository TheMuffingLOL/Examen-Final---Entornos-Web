document.getElementById("registroBtn").onclick = function(event) {
    event.preventDefault();
        const nombre = document.getElementById("nombre").value;
        const user = document.getElementById("user").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirm-password").value;
            if (nombre && user && email && password && confirmPassword) {
                if (password === confirmPassword) {
    location.href = "002_MainScreen.html";
    } else {
    alert("Las contraseñas no coinciden.");
    }
    } else {
    alert("Por favor, completa todos los campos.");
    }
};