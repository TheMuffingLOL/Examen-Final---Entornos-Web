function increaseVolume() {
    var video = document.getElementById('videoPlayer');
    if (video.volume < 1) {
        video.volume += 0.1;
    }
 }
 
 function decreaseVolume() {
    var video = document.getElementById('videoPlayer');
    if (video.volume > 0) {
        video.volume -= 0.1;
    }
 }
 
 // Función para desplazarse al video
 function scrollToVideo() {
    var videoSection = document.getElementById('videoContainer');
    videoSection.scrollIntoView({ behavior: 'smooth' });
 }